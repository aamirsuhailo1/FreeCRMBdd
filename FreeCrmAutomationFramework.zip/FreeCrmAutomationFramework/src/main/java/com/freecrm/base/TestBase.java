/**
 * 
 */
package com.freecrm.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * 
 * @author hp
 *
 */
public class TestBase {
	
	static {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("current.date.time", sdf.format(new Date()));
	}
	
	public WebDriver driver=null;
	public Properties prop;
	public Logger logger;
	
	/**
	 * This method will Initialize Logger, property file and WebDriver instance 
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public WebDriver init() throws FileNotFoundException, IOException, InterruptedException {
		initializeLogger();
		initPropertyFiles();
		if(driver==null) {
		//Launching the browser
		 System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver.exe");
		 driver = new ChromeDriver();
		//Maximizing browser window
		 driver.manage().window().maximize();
		//Navigating to url
		 driver.get(prop.getProperty("url"));
		 Thread.sleep(5000);
		}
		
		 
		 return driver;
	}
	
	/**
	 * Property file initialization
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void initPropertyFiles() throws FileNotFoundException, IOException {
		prop = new Properties();// creating the object for the Properities Constructor which is class in Properities file
		prop.load(new FileInputStream("./src/main/java/com/freecrm/config/setup.properties"));
		
	}
	
	/**
	 * Log4j Initialization
	 */
	public void initializeLogger() {
		logger = Logger.getLogger(this.getClass()); 
	}

}
