/**
 * 
 */
package com.freecrm.stepDefinitions;



import org.openqa.selenium.WebDriver;

import com.freecrm.base.TestBase;
import com.freecrm.pages.HomePage;
import com.freecrm.pages.LoginPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Assert;

/**
 * @author hp
 *
 */

public class LoginStepDefinitionWithParameters extends TestBase {
	
	WebDriver driver;
	String titleLoginPage;
	LoginPage login;
	HomePage homepage;
	String userName;
	String password;
	String homepageFirstItem;
	
	public LoginStepDefinitionWithParameters() throws FileNotFoundException, IOException, InterruptedException {
		driver = init();
		login = new LoginPage(driver);
		homepage = new HomePage(driver);
	}
	

	@When("^user enters the username as \"([^\"]*)\"$")
	public void user_enters_the_username_as(String uname) {
		
		   login.enterUserName(uname);
		   logger.info("Username is entered");
	}

	@And("^user enters the password as \"([^\"]*)\"$")
	public void user_enters_the_password_as(String pwd) {
		
	    login.enterPassword(pwd);
	    logger.info("Password is entered");
	    
	}
	
 


}
