/**
 * 
 */
package com.freecrm.stepDefinitions;



import org.openqa.selenium.WebDriver;

import com.freecrm.base.TestBase;
import com.freecrm.pages.HomePage;
import com.freecrm.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Assert;

/**
 * @author hp
 *
 */

public class LoginStepDefinition extends TestBase {
	
	WebDriver driver;
	String titleLoginPage;
	LoginPage login;
	HomePage homepage;
	String userName;
	String password;
	String homepageFirstItem;
	
	public LoginStepDefinition() throws FileNotFoundException, IOException, InterruptedException {
		driver = init();
		login = new LoginPage(driver);
		homepage = new HomePage(driver);
	}
	
	
	@Given("^user is on login page$")
	public void user_is_on_the_login_page() {
	   titleLoginPage = driver.getTitle();
	   logger.info("Login Page title is : "+titleLoginPage);
	   Assert.assertEquals(titleLoginPage, "Cogmento CRM");
	   logger.info("Verfied Login page launch successfully");
	}

	@When("^user enters the username$")
	public void user_enters_username() {
	   userName = prop.getProperty("username");
	   login.enterUserName(userName);
	   logger.info("Username is entered");
	}

	@When("^user enters the password$")
	public void user_enters_password() {
		password = prop.getProperty("password");
	    login.enterPassword(password);
	    logger.info("Password is entered");
	}

	@When("^user clicks on the Login button$")
	public void user_clicks_on_Login_button() throws InterruptedException {
	    login.clickOnLoginButton();
	    logger.info("Clicked on Login button");
	}

	@Then("^user should land on the home page$")
	public void user_should_land_on_home_page() {
	    homepageFirstItem = homepage.getFirstMenuItem();
	    logger.info("Home Page First menu item is : "+homepageFirstItem);
	    Assert.assertEquals("Home", homepageFirstItem);
	    logger.info("verified homepage landing after logging in successfully");
	}
 


}
