$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("./src/test/resources/features/freecrmloginWithParameters.feature");
formatter.feature({
  "line": 1,
  "name": "FreeCrm login.",
  "description": "",
  "id": "freecrm-login.",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "User logins using correct credentials",
  "description": "",
  "id": "freecrm-login.;user-logins-using-correct-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user enters the username as \"aamirmohammedsuhail@gmail.com\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "user enters the password as \"asdf1234$A\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "user clicks on the Login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "user should land on the home page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginStepDefinition.user_is_on_the_login_page()"
});
